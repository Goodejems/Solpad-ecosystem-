# SolPad Frontend (Cloudflare Pages)

Ready for easy deployment via **GitHub + Cloudflare Pages**.

## How to Deploy (GitHub method)

### 1. Create GitHub Repository
- Go to https://github.com/new
- Name it: `solpad-frontend`
- Set to **Public**
- Do **not** add README
- Click **Create repository**

### 2. Upload these files
Upload **all** the files in this folder:
- `index.html`
- `solpad-config.js`
- `_headers`
- `_redirects`
- `.well-known` folder
- `README.md`

### 3. Connect to Cloudflare Pages
1. Go to https://dash.cloudflare.com
2. **Workers & Pages** → **Create** → **Pages** → **Connect to Git**
3. Select the `solpad-frontend` repository
4. Settings:
   - Framework preset: **None**
   - Build command: (leave empty)
   - Build output directory: `/` or leave empty
5. Click **Save and Deploy**

Done! Your site will be live on `*.pages.dev`

## After Deploy
Update `solpad-config.js` with your backend Worker URL:

```js
window.SOLPAD_API_BASE = 'https://your-backend.workers.dev';
window.SOLPAD_FRONTEND_ONLY = false;
```

Then commit the change on GitHub — Cloudflare will auto-redeploy.
