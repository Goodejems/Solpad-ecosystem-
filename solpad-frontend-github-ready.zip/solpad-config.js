/**
 * SolPad Frontend — connected to live backend
 * Backend: https://solpad-community-backend-v2-mu.vercel.app
 */
(function () {
  'use strict';

  window.SOLPAD_API_BASE = 'https://solpad-community-backend-v2-mu.vercel.app';
  window.SOLPAD_FRONTEND_ONLY = false;

  try {
    window.SOLPAD_WEB_ORIGIN = (window.location.origin || '').replace(/\/$/, '');
  } catch (e) {
    window.SOLPAD_WEB_ORIGIN = '';
  }

  // Public RPCs only (no Helius key in browser)
  window.SOLPAD_RPCS = [
    'https://solana-rpc.publicnode.com',
    'https://api.mainnet-beta.solana.com',
    'https://solana.publicnode.com'
  ];

  window.SOLPAD_CONFIG = {
    enableLiveTelemetry: false,
    enableHODLClaimApi: true,
    enableOwnerApi: true,
    enableFeesApi: true,
    enableServerScan: false,      // backend scan is stub; use client scan
    enableClientOnchainScan: true,
    enableMarketDiscovery: true,
    enableHODLScan: true,

    telemetryIntervalMs: 20000,
    hodlScanIntervalMs: 60000,
    hodlScanOnConnectDelayMs: 1500,
    discoveryRefreshMs: 45000,
    debounceWalletEventsMs: 600,

    dexScreenerApi: 'https://api.dexscreener.com',
    jupiterPriceApi: 'https://price.jup.ag/v6/price'
  };

  console.log('✅ SolPad config loaded | API:', window.SOLPAD_API_BASE, '| frontendOnly:', window.SOLPAD_FRONTEND_ONLY);
})();
